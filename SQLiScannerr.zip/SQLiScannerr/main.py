from kivy.app import App
from kivy.uix.tabbedpanel import TabbedPanel
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner
from kivy.uix.scrollview import ScrollView
from kivy.uix.treeview import TreeView, TreeViewLabel
from kivy.uix.popup import Popup
from kivy.clock import Clock
import threading
import os
from sqlmap_wrapper import SQLMapScanner
from telegram_reporter import TelegramReporter

class SQLiScannerApp(App):
    def build(self):
        # Initialize components
        self.scanner = SQLMapScanner()
        self.reporter = TelegramReporter()
        
        # Main UI
        self.tabs = TabbedPanel(do_default_tab=False)
        
        # Tab 1: Scanner
        scan_tab = BoxLayout(orientation='vertical')
        self.setup_scan_tab(scan_tab)
        self.tabs.add_widget(scan_tab)
        
        # Tab 2: Database Explorer
        db_tab = BoxLayout(orientation='vertical')
        self.setup_db_tab(db_tab)
        self.tabs.add_widget(db_tab)
        
        # Tab 3: Live Output
        output_tab = ScrollView()
        self.output_label = Label(
            text="[color=ffffff]Ready to scan...[/color]",
            markup=True,
            size_hint_y=None,
            halign='left',
            valign='top'
        )
        self.output_label.bind(size=self.update_text_size)
        output_tab.add_widget(self.output_label)
        self.tabs.add_widget(output_tab)
        
        return self.tabs
    
    def setup_scan_tab(self, layout):
        # Target URL
        layout.add_widget(Label(text="[b]Target URL[/b]", markup=True))
        self.url_input = TextInput(
            hint_text="https://example.com/page.php?id=1",
            multiline=False
        )
        layout.add_widget(self.url_input)
        
        # Scan Options Grid
        options_grid = BoxLayout(orientation='vertical', spacing=10)
        
        # Level Selection
        level_box = BoxLayout(size_hint_y=None, height=40)
        level_box.add_widget(Label(text="Scan Level:"))
        self.level_spinner = Spinner(
            values=["1 - Default", "3 - Aggressive", "5 - Full"],
            text="1 - Default"
        )
        level_box.add_widget(self.level_spinner)
        options_grid.add_widget(level_box)
        
        # Risk Selection
        risk_box = BoxLayout(size_hint_y=None, height=40)
        risk_box.add_widget(Label(text="Risk Level:"))
        self.risk_spinner = Spinner(
            values=["1 - Low", "2 - Medium", "3 - High"],
            text="1 - Low"
        )
        risk_box.add_widget(self.risk_spinner)
        options_grid.add_widget(risk_box)
        
        layout.add_widget(options_grid)
        
        # Start Button
        self.scan_btn = Button(
            text="Start Scan",
            size_hint_y=None,
            height=60,
            background_color=(0.2, 0.6, 1, 1)
        )
        self.scan_btn.bind(on_press=self.start_scan)
        layout.add_widget(self.scan_btn)
    
    def setup_db_tab(self, layout):
        # Database Tree View
        self.db_tree = TreeView(hide_root=True)
        layout.add_widget(self.db_tree)
        
        # Dump Controls
        dump_box = BoxLayout(size_hint_y=None, height=60)
        self.dump_btn = Button(
            text="Dump Selected",
            background_color=(0.9, 0.3, 0.3, 1)
        )
        self.dump_btn.bind(on_press=self.dump_selected)
        dump_box.add_widget(self.dump_btn)
        layout.add_widget(dump_box)
    
    def start_scan(self, instance):
        target = self.url_input.text
        level = self.level_spinner.text.split()[0]
        risk = self.risk_spinner.text.split()[0]
        
        # Disable button during scan
        self.scan_btn.disabled = True
        self.scan_btn.text = "Scanning..."
        
        # Start scan in background
        threading.Thread(
            target=self.run_scan,
            args=(target, level, risk)
        ).start()
    
    def run_scan(self, target, level, risk):
        # Initialize scanner
        self.scanner.set_target(target)
        self.scanner.set_options(level=level, risk=risk)
        
        # Start scan with callback for live output
        self.scanner.scan(
            callback=self.update_output,
            on_complete=self.scan_complete
        )
    
    def update_output(self, text):
        Clock.schedule_once(lambda dt: self._update_output(text))
    
    def _update_output(self, text):
        self.output_label.text += f"\n[color=aaaaaa]{text}[/color]"
    
    def scan_complete(self, result):
        Clock.schedule_once(lambda dt: self._scan_complete(result))
    
    def _scan_complete(self, result):
        # Re-enable button
        self.scan_btn.disabled = False
        self.scan_btn.text = "Start Scan"
        
        # Show results
        self.output_label.text += "\n[color=00ff00]Scan complete![/color]"
        
        # Populate database tree
        if 'databases' in result:
            self.populate_db_tree(result['databases'])
        
        # Send Telegram report
        self.reporter.send_report(result)
    
    def populate_db_tree(self, databases):
        self.db_tree.clear()
        
        for db_name, db_data in databases.items():
            db_node = self.db_tree.add_node(TreeViewLabel(
                text=f"[b]{db_name}[/b]",
                markup=True
            ))
            
            for table_name, table_data in db_data['tables'].items():
                table_node = self.db_tree.add_node(TreeViewLabel(
                    text=f"📁 {table_name}",
                    markup=True
                ), db_node)
                
                for column in table_data['columns']:
                    self.db_tree.add_node(TreeViewLabel(
                        text=f"│   ➔ {column['name']} ({column['type']})",
                        markup=True
                    ), table_node)
    
    def dump_selected(self, instance):
        selected = self.db_tree.selected_node
        if selected:
            path = self.get_node_path(selected)
            self.output_label.text += f"\n[color=ffff00]Dumping: {path}[/color]"
            
            # Get full path (DB → Table → Column)
            if len(path.split(" → ")) == 3:
                db, table, column = path.split(" → ")
                self.scanner.dump_data(db, table, [column])
    
    def get_node_path(self, node):
        path = []
        while node:
            path.insert(0, node.text.replace("[b]", "").replace("[/b]", ""))
            node = node.parent_node
        return " → ".join(path)

if __name__ == "__main__":
    SQLiScannerApp().run()